# YZM 411 – Ödev 1: Renk, Aydınlatma ve Örnekleme

## Klasör düzeni
```
YZM411_Odev1_OgrenciNo/
├── data/                 # girdi: normal.jpg (IMG_7798), golge.jpg (IMG_7797), lamba.jpg (IMG_7795)
├── odev1.py              # ana kod (VS Code'da "# %%" hücreleriyle de çalışır)
├── results/              # kodun ürettiği CSV tabloları, şekiller, konsol çıktısı, run_info.json
├── rapor/
│   ├── tahminler.md      # kod çalıştırılmadan ÖNCE yazılan tahminler
│   ├── rapor_olustur.py  # PDF raporu results/*.csv'den üretir
│   └── YZM411_Odev1_Rapor.pdf
├── sonuc_tablosu.csv     # özet sonuç tablosu
├── KAYNAK_BEYANI.md      # kaynaklar + yapay zekâ beyanı
├── requirements.txt
└── README.md
```

## Çalıştırma sırası
```
pip install -r requirements.txt
python odev1.py                   # Hücre 0→6, results/ ve sonuc_tablosu.csv üretilir
python rapor/rapor_olustur.py     # rapor/YZM411_Odev1_Rapor.pdf (önce rapor_olustur.py'deki 3 alanı doldurun)
```
Sürümler (çalıştırılan ortam): Python 3.13.18, NumPy 2.5.3, OpenCV 5.0.0, matplotlib 3.11.2, pandas 3.0.5, SciPy 1.18.1
(results/run_info.json ve konsol_ciktisi.txt içinde de kayıtlıdır). Rastgelelik kullanılmaz; sonuçlar deterministiktir.

## Önemli notlar
- Eşikler (RGB, HSV) yalnızca normal fotoğraftaki kalem kapağı bölgesinden belirlenip dondurulmuştur; sonradan değiştirilmemiştir.
- "Tanı 2" (V_min=60) post-hoc bir tanıdır, dondurulmuş karşılaştırmanın parçası değildir.
- Gölge/lamba koşullarının nasıl oluşturulduğu ve EXIF eksikliği raporun "Veri ve sınırlar" bölümündedir.

# %% [markdown]
# # YZM 411 Ödev 1 – Renk, Aydınlatma ve Örnekleme
# Çalıştırma: `python odev1.py` (ya da VS Code'da "# %%" hücrelerini sırayla çalıştırın).
# Çalıştırma sırası: Hücre 0 → 1 → 2 → 3 → 4 → 5 → 6. Tüm çıktılar `results/` içine yazılır.
# Tahminler `rapor/tahminler.md` içinde, kod çalıştırılmadan önce yazılmıştır.

# %% Hücre 0 – Ayarlar, giriş dosyaları, paket sürümleri
import json
import os
import platform

import cv2
import matplotlib
import numpy as np
import pandas as pd
import scipy

matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
OUT = os.path.join(BASE, "results")
os.makedirs(OUT, exist_ok=True)

# Giriş dosyaları (orijinal telefon dosya adları: normal=IMG_7798, golge=IMG_7797, lamba=IMG_7795)
FILES = {"normal": "normal.jpg", "golge": "golge.jpg", "lamba": "lamba.jpg"}
ORDER = ["normal", "golge", "lamba"]

# --- Dondurulmuş eşikler (Adım 5) ---
# Yalnızca NORMAL fotoğraftaki kalem kapağından alınan küçük bir bölgeye (ROI) bakılarak
# belirlendi; sonradan hiçbir fotoğraf için değiştirilmedi.
# Kural: alt sınır = ROI'nin %2'lik değeri − ~30 (yuvarlanmış); üst sınır = %98 + ~15;
# ton (H) aralığı = ROI'nin H aralığı ± 3.
ROI = dict(x0=225, x1=260, y0=1085, y1=1125)  # normal.jpg üzerinde (x: sütun, y: satır)
RGB_MIN = np.array([150, 150, 0])    # R>=150, G>=150
RGB_MAX = np.array([255, 255, 130])  # B<=130
HSV_MIN = np.array([28, 110, 150])   # OpenCV 8 bit HSV: H 0-179, S 0-255, V 0-255
HSV_MAX = np.array([36, 255, 255])

# Adım 6 parametreleri
B_SHIFT = 40
GAMMAS = [0.5, 2.0]

# Adım 7 kesitleri (normal.jpg, [y0:y1, x0:x1]); boyutlar 4'e tam bölünür
CROPS = {
    "cizgili_kagit": dict(x0=840, x1=1240, y0=1400, y1=1640),  # 400x240
    "kalem_yazi": dict(x0=396, x1=492, y0=1256, y1=1352),      # 96x96
}
SCALE = 4

versions = {
    "python": platform.python_version(),
    "numpy": np.__version__,
    "opencv": cv2.__version__,
    "matplotlib": matplotlib.__version__,
    "pandas": pd.__version__,
    "scipy": scipy.__version__,
}
print("Paket sürümleri:", versions)
print("Giriş dosyaları:", FILES)
print("Dondurulmuş eşikler: RGB", RGB_MIN, RGB_MAX, "HSV", HSV_MIN, HSV_MAX)

# %% Hücre 1 – Adım 4a/4c: Görüntülerin sayısal yapısı, BGR → RGB
bgr = {k: cv2.imread(os.path.join(DATA, FILES[k])) for k in ORDER}
assert all(v is not None for v in bgr.values()), "Bir görüntü okunamadı"
rgb = {k: cv2.cvtColor(v, cv2.COLOR_BGR2RGB) for k, v in bgr.items()}
hsv = {k: cv2.cvtColor(v, cv2.COLOR_BGR2HSV) for k, v in bgr.items()}

rows = []
for k in ORDER:
    a = bgr[k]
    rows.append(dict(foto=k, dosya=FILES[k], H=a.shape[0], W=a.shape[1], C=a.shape[2],
                     dtype=str(a.dtype), min=int(a.min()), max=int(a.max()),
                     ortalama=round(float(rgb[k].mean()), 2)))
df_yapi = pd.DataFrame(rows)
print(df_yapi.to_string(index=False))
df_yapi.to_csv(os.path.join(OUT, "sayisal_yapi.csv"), index=False)

# img[y, x, kanal] erişimi ve BGR/RGB sırası
y_t, x_t = 1100, 240
print(f"\nimg[y={y_t}, x={x_t}] OpenCV (BGR) = {bgr['normal'][y_t, x_t]}  ->  RGB = {rgb['normal'][y_t, x_t]}")
assert tuple(bgr["normal"][y_t, x_t]) == tuple(rgb["normal"][y_t, x_t][::-1])
assert bgr["normal"][y_t, x_t, 0] == rgb["normal"][y_t, x_t, 2]  # kanal 0: B ↔ R

# %% Hücre 2 – Adım 4b: Aynı fiziksel bölgeden 3 piksel, 3 fotoğrafta
# Kalem her karede birkaç piksel kaydığı için "aynı koordinat" yerine "aynı fiziksel nokta"
# kullanılır: noktalar kalemin uzun ekseni boyunca (kapak, gövde, uç) konumlandırılır.
# Eksen, yalnızca KONUM bulmak için gevşek bir sarı maskeyle bulunur (sonuç maskesiyle ilgisi yok).


def kalem_noktalari(img_bgr, fractions=(0.10, 0.40, 0.70)):
    h = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    loose = ((h[..., 0] >= 22) & (h[..., 0] <= 40) & (h[..., 1] > 90) & (h[..., 2] > 50)).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(loose, connectivity=8)
    big = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    ys, xs = np.nonzero(lab == big)
    pts = np.c_[xs, ys].astype(float)
    c = pts.mean(0)
    d = np.linalg.svd(pts - c, full_matrices=False)[2][0]
    t = (pts - c) @ d
    if d[0] < 0:  # yönü her karede aynı tut: soldan sağa
        d, t = -d, -t
    out = []
    for f in fractions:
        p = c + d * (t.min() + f * (t.max() - t.min()))
        out.append((int(round(p[0])), int(round(p[1]))))
    return out


nokta_adlari = ["kapak", "govde", "govde_arka"]
pt = {k: kalem_noktalari(bgr[k]) for k in ORDER}
rows = []
for i, ad in enumerate(nokta_adlari):
    for k in ORDER:
        x, y = pt[k][i]
        r, g, b = (int(v) for v in rgb[k][y, x])
        patch = rgb[k][y - 2:y + 3, x - 2:x + 3].reshape(-1, 3).mean(0)
        hh, ss, vv = (int(v) for v in hsv[k][y, x])
        rows.append(dict(nokta=ad, foto=k, x=x, y=y, R=r, G=g, B=b, H=hh, S=ss, V=vv,
                         R_5x5=round(patch[0], 1), G_5x5=round(patch[1], 1), B_5x5=round(patch[2], 1)))
df_piksel = pd.DataFrame(rows)
print(df_piksel.to_string(index=False))
df_piksel.to_csv(os.path.join(OUT, "piksel_degerleri.csv"), index=False)

fig, axs = plt.subplots(1, 3, figsize=(12, 5))
for ax, k in zip(axs, ORDER):
    x0, x1, y0, y1 = 150, 700, 1000, 1480
    ax.imshow(rgb[k][y0:y1, x0:x1])
    for (x, y), ad in zip(pt[k], nokta_adlari):
        ax.plot(x - x0, y - y0, "r+", ms=14, mew=2)
        ax.text(x - x0 + 8, y - y0 - 8, ad, color="red", fontsize=9)
    ax.set_title(k)
    ax.axis("off")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "piksel_noktalari.png"), dpi=110)
plt.close(fig)

# %% Hücre 3 – Adım 5: Sabit RGB ve HSV eşikleri, 6 maske
r = ROI
roi_rgb = rgb["normal"][r["y0"]:r["y1"], r["x0"]:r["x1"]].reshape(-1, 3)
roi_hsv = hsv["normal"][r["y0"]:r["y1"], r["x0"]:r["x1"]].reshape(-1, 3)
print("ROI (normal) RGB min/med/max:", roi_rgb.min(0), np.median(roi_rgb, 0), roi_rgb.max(0))
print("ROI (normal) HSV min/med/max:", roi_hsv.min(0), np.median(roi_hsv, 0), roi_hsv.max(0))


def rgb_maske(img_rgb):
    return cv2.inRange(img_rgb, RGB_MIN.astype(np.uint8), RGB_MAX.astype(np.uint8)) > 0


def hsv_maske(img_hsv):
    return cv2.inRange(img_hsv, HSV_MIN.astype(np.uint8), HSV_MAX.astype(np.uint8)) > 0


maskeler, rows, extra_rows = {}, [], []
for k in ORDER:
    for ad, fn, src in [("RGB", rgb_maske, rgb[k]), ("HSV", hsv_maske, hsv[k])]:
        m = fn(src)
        maskeler[(k, ad)] = m
        alan = m.mean() * 100
        n, lab, stats, cent = cv2.connectedComponentsWithStats(m.astype(np.uint8), connectivity=8)
        areas = stats[1:, cv2.CC_STAT_AREA]
        buyuk = areas[areas >= 100]
        en_buyuk = int(areas.max()) if len(areas) else 0
        rows.append(dict(foto=k, maske=ad, piksel=int(m.sum()), alan_orani_yuzde=round(alan, 3),
                         bilesen_sayisi_ge100=len(buyuk), en_buyuk_bilesen=en_buyuk,
                         en_buyuk_disindaki_piksel=int(m.sum()) - en_buyuk))
        # kalem dışı bileşenler: en büyük bileşen dışındaki ≥100 pikselli bileşenler
        big_id = 1 + int(np.argmax(areas)) if len(areas) else None
        for i in range(1, n):
            if i != big_id and stats[i, cv2.CC_STAT_AREA] >= 100:
                mm = lab == i
                extra_rows.append(dict(foto=k, maske=ad, alan=int(stats[i, cv2.CC_STAT_AREA]),
                                       cx=int(cent[i][0]), cy=int(cent[i][1]),
                                       medyan_RGB=tuple(int(v) for v in np.median(rgb[k][mm], 0)),
                                       medyan_HSV=tuple(int(v) for v in np.median(hsv[k][mm], 0))))

df_maske = pd.DataFrame(rows)
print(df_maske.to_string(index=False))
df_maske.to_csv(os.path.join(OUT, "maske_sonuclari.csv"), index=False)
df_extra = pd.DataFrame(extra_rows)
print("\nEn büyük bileşen dışındaki (≥100 piksel) bileşenler:")
print(df_extra.to_string(index=False) if len(df_extra) else "(yok)")
df_extra.to_csv(os.path.join(OUT, "maske_ek_bilesenler.csv"), index=False)


# --- Tanı (eşikleri DEĞİŞTİRMEZ): kalem pikselleri hangi tek koşulda elendi? ---
# Kalem bölgesi = gevşek sarı maskenin en büyük bileşeni (yalnızca konum için, hücre 2'deki gibi).
rows = []
for k in ORDER:
    h_ = hsv[k]
    loose = ((h_[..., 0] >= 22) & (h_[..., 0] <= 40) & (h_[..., 1] > 90) & (h_[..., 2] > 50)).astype(np.uint8)
    n_, lab_, st_, _ = cv2.connectedComponentsWithStats(loose, connectivity=8)
    pen = lab_ == (1 + int(np.argmax(st_[1:, cv2.CC_STAT_AREA])))
    R_, G_, B_ = (rgb[k][..., i][pen].astype(int) for i in range(3))
    H_, S_, V_ = (hsv[k][..., i][pen].astype(int) for i in range(3))
    pct = lambda c: round(float(c.mean() * 100), 1)
    rows.append(dict(foto=k, kalem_piksel=int(pen.sum()),
                     R_ge150=pct(R_ >= 150), G_ge150=pct(G_ >= 150), B_le130=pct(B_ <= 130),
                     H_28_36=pct((H_ >= 28) & (H_ <= 36)), S_ge110=pct(S_ >= 110), V_ge150=pct(V_ >= 150),
                     H_medyan=int(np.median(H_)), S_medyan=int(np.median(S_)), V_medyan=int(np.median(V_))))
df_tani = pd.DataFrame(rows)
print("\nKalem pikselleri için tek tek koşulları geçme yüzdesi:")
print(df_tani.to_string(index=False))
df_tani.to_csv(os.path.join(OUT, "maske_tani.csv"), index=False)

# --- Tanı 2 (POST-HOC; dondurulmuş karşılaştırmaya DAHİL DEĞİL, yalnızca "neden" sorusu için) ---
# Gölgede HSV maskesi neden çöktü? V alt sınırını 150 → 60'a düşürsek ne olur? (H ve S aynı)
rows = []
for k in ORDER:
    m = cv2.inRange(hsv[k], np.array([28, 110, 60], np.uint8), np.array([36, 255, 255], np.uint8)) > 0
    n_, lab_, st_, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), connectivity=8)
    a_ = st_[1:, cv2.CC_STAT_AREA]
    rows.append(dict(foto=k, hsv_Vmin60_piksel=int(m.sum()), alan_orani_yuzde=round(float(m.mean() * 100), 3),
                     en_buyuk_bilesen=int(a_.max()), disindaki_piksel=int(m.sum()) - int(a_.max())))
df_tani2 = pd.DataFrame(rows)
print("\nTanı 2 – HSV, V_min=60 (post-hoc):")
print(df_tani2.to_string(index=False))
df_tani2.to_csv(os.path.join(OUT, "maske_tani2_posthoc_Vmin60.csv"), index=False)

# Şekil: üst satır özgün fotoğraflar, altta RGB maskeleri, en altta HSV maskeleri
fig, axs = plt.subplots(3, 3, figsize=(10, 12))
for j, k in enumerate(ORDER):
    axs[0, j].imshow(rgb[k]); axs[0, j].set_title(f"{k}")
    for i, ad in [(1, "RGB"), (2, "HSV")]:
        m = maskeler[(k, ad)]
        axs[i, j].imshow(m, cmap="gray", vmin=0, vmax=1)
        axs[i, j].set_title(f"{ad} maske  (alan %{m.mean() * 100:.2f})")
for a in axs.ravel():
    a.axis("off")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "maskeler.png"), dpi=90)
plt.close(fig)

# %% Hücre 4 – Adım 6: Parlaklık kaydırması ve gama (NumPy, float)


def parlaklik_kaydir(img, b):
    """J = clip(I + b, 0, 255); float32 üzerinde."""
    return np.clip(img.astype(np.float32) + b, 0, 255)


def gama_donusumu(img, gamma):
    """J = 255 * (I/255)**gamma ; gama formüldeki üstür (1/gamma değil). float32 üzerinde."""
    return np.clip(255.0 * (img.astype(np.float32) / 255.0) ** gamma, 0, 255)


# Ödevdeki örnek: 64 değerli piksel
ornek = np.array([[[64, 64, 64]]], dtype=np.uint8)
print("64 -> gama 0.5:", gama_donusumu(ornek, 0.5)[0, 0, 0], "| gama 2.0:", gama_donusumu(ornek, 2.0)[0, 0, 0])
assert abs(gama_donusumu(ornek, 0.5)[0, 0, 0] - 128) < 0.5
assert abs(gama_donusumu(ornek, 2.0)[0, 0, 0] - 16) < 0.5

I = rgb["normal"]
m0 = float(I.mean())
sonuc = {"orijinal": I.astype(np.float32),
         f"parlaklik_+{B_SHIFT}": parlaklik_kaydir(I, B_SHIFT)}
for g in GAMMAS:
    sonuc[f"gama_{g}"] = gama_donusumu(I, g)

rows = []
for ad, J in sonuc.items():
    rows.append(dict(donusum=ad, ortalama=round(float(J.mean()), 2),
                     R=round(float(J[..., 0].mean()), 2), G=round(float(J[..., 1].mean()), 2),
                     B=round(float(J[..., 2].mean()), 2),
                     piksel_255_orani_yuzde=round(float((J >= 255).mean() * 100), 3),
                     piksel_0_orani_yuzde=round(float((J <= 0).mean() * 100), 3)))
df_pg = pd.DataFrame(rows)

# Beklenen (saf formül) değerler ve fark nedeni
ham = I.astype(np.float32) + B_SHIFT
kirpilan_kayip = float(np.maximum(ham - 255, 0).mean())  # 255 üstüne taşan kısmın ortalamaya etkisi
beklenen_kaydirma = m0 + B_SHIFT
olculen_kaydirma = float(sonuc[f"parlaklik_+{B_SHIFT}"].mean())
assert abs((beklenen_kaydirma - kirpilan_kayip) - olculen_kaydirma) < 1e-3  # fark tamamen kırpma
print(df_pg.to_string(index=False))
print(f"\nOrtalama (orijinal) = {m0:.2f}")
print(f"b=+{B_SHIFT}: beklenen = {beklenen_kaydirma:.2f}, ölçülen = {olculen_kaydirma:.2f}, "
      f"kırpma kaybı = {kirpilan_kayip:.2f}  (255'e kırpılan piksel oranı: "
      f"%{(ham > 255).mean() * 100:.2f})")
for g in GAMMAS:
    naif = 255.0 * (m0 / 255.0) ** g
    print(f"gama {g}: ortalamaya uygulanmış formül = {naif:.2f}, ölçülen = {sonuc[f'gama_{g}'].mean():.2f}")
df_pg["beklenen_naif"] = [round(m0, 2), round(beklenen_kaydirma, 2)] + \
    [round(255.0 * (m0 / 255.0) ** g, 2) for g in GAMMAS]
df_pg.to_csv(os.path.join(OUT, "parlaklik_gama.csv"), index=False)

fig, axs = plt.subplots(2, 4, figsize=(14, 8))
for j, (ad, J) in enumerate(sonuc.items()):
    axs[0, j].imshow(J.astype(np.uint8)); axs[0, j].set_title(f"{ad}\nort={J.mean():.1f}"); axs[0, j].axis("off")
    axs[1, j].hist(J.ravel(), bins=64, range=(0, 255), color="gray")
    axs[1, j].set_xlim(0, 255); axs[1, j].set_title("histogram (tüm kanallar)")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "parlaklik_gama.png"), dpi=80)
plt.close(fig)

# %% Hücre 5 – Adım 7: 1/4 küçültme (INTER_NEAREST ve INTER_AREA)
rows = []
fig, axs = plt.subplots(len(CROPS), 3, figsize=(12, 4.8 * len(CROPS)))
for i, (ad, c) in enumerate(CROPS.items()):
    crop = bgr["normal"][c["y0"]:c["y1"], c["x0"]:c["x1"]]
    h, w = crop.shape[:2]
    assert h % SCALE == 0 and w % SCALE == 0
    small_n = cv2.resize(crop, (w // SCALE, h // SCALE), interpolation=cv2.INTER_NEAREST)
    small_a = cv2.resize(crop, (w // SCALE, h // SCALE), interpolation=cv2.INTER_AREA)
    # yalnızca göstermek için en yakın komşuyla özgün boyuta büyütme
    up_n = cv2.resize(small_n, (w, h), interpolation=cv2.INTER_NEAREST)
    up_a = cv2.resize(small_a, (w, h), interpolation=cv2.INTER_NEAREST)
    g0 = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY).astype(np.float32)
    gn = cv2.cvtColor(up_n, cv2.COLOR_BGR2GRAY).astype(np.float32)
    ga = cv2.cvtColor(up_a, cv2.COLOR_BGR2GRAY).astype(np.float32)
    # Ayrıntı ölçüleri: gri düzeyde standart sapma (kontrast) ve Laplacian varyansı (keskinlik)
    lap = lambda g: float(cv2.Laplacian(g, cv2.CV_32F).var())
    rows.append(dict(kesit=ad, boyut_ozgun=f"{w}x{h}", boyut_kucuk=f"{w // SCALE}x{h // SCALE}",
                     std_ozgun=round(float(g0.std()), 2), std_nearest=round(float(gn.std()), 2),
                     std_area=round(float(ga.std()), 2),
                     lapvar_ozgun=round(lap(g0), 1), lapvar_nearest=round(lap(gn), 1),
                     lapvar_area=round(lap(ga), 1),
                     MAE_nearest_ozgunle=round(float(np.abs(gn - g0).mean()), 2),
                     MAE_area_ozgunle=round(float(np.abs(ga - g0).mean()), 2)))
    for j, (img, t) in enumerate([(crop, f"özgün {w}x{h}"),
                                  (up_n, f"INTER_NEAREST 1/4 → ×4 büyütülmüş"),
                                  (up_a, f"INTER_AREA 1/4 → ×4 büyütülmüş")]):
        axs[i, j].imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), interpolation="nearest")
        axs[i, j].set_title(f"{ad}: {t}", fontsize=9); axs[i, j].axis("off")
    cv2.imwrite(os.path.join(OUT, f"kesit_{ad}_ozgun.png"), crop)
    cv2.imwrite(os.path.join(OUT, f"kesit_{ad}_nearest.png"), up_n)
    cv2.imwrite(os.path.join(OUT, f"kesit_{ad}_area.png"), up_a)

    if ad == "cizgili_kagit":
        # Çizgi profili: bir sütun şeridinin ortalaması boyunca satır değerleri
        # (çizgiler koyu çukurlar). Küçültülmüş görüntü ×4 büyütülmüş hâliyle karşılaştırılır.
        sl = slice(w // 2 - 4, w // 2 + 4)
        prof = [g0[:, sl].mean(1), gn[:, sl].mean(1), ga[:, sl].mean(1)]
        pf, pa = plt.subplots(figsize=(10, 3.4))
        for p, lbl in zip(prof, ["özgün", "NEAREST", "AREA"]):
            pa.plot(p, label=lbl, lw=1.3)
        pa.set_xlabel("satır (y)"); pa.set_ylabel("gri değer"); pa.legend(); pa.set_title("Çizgili kâğıt: dikey profil")
        pf.tight_layout(); pf.savefig(os.path.join(OUT, "cizgi_profili.png"), dpi=100); plt.close(pf)
        # Çizgi sayımı: kesiti 5 dar dikey şeride (8 sütun) böl, her şeridin dikey profilinde
        # belirgin koyu çukurları (çizgiler) say. Çukur = çevresinden en az 4 gri düzey koyu.
        from scipy.signal import find_peaks
        sonuc_cizgi = {}
        for ad_m, G in [("ozgun", g0), ("nearest", gn), ("area", ga)]:
            sayilar, derinlikler = [], []
            for xs0 in np.linspace(40, w - 48, 5).astype(int) // 4 * 4:
                p = G[:, xs0:xs0 + 8].mean(1)
                pk, pr = find_peaks(-p, prominence=4)
                sayilar.append(len(pk)); derinlikler += list(pr["prominences"])
            sonuc_cizgi[ad_m] = (sayilar, float(np.median(derinlikler)) if derinlikler else 0.0)
            print(f"Çizgi sayısı (5 şerit) {ad_m}: {sayilar}  medyan çukur derinliği = {sonuc_cizgi[ad_m][1]:.1f}")
        rows[-1].update({f"cizgi_serit_{m}": str(v[0]) for m, v in sonuc_cizgi.items()})
        rows[-1].update({f"cizgi_derinlik_{m}": round(v[1], 1) for m, v in sonuc_cizgi.items()})
fig.tight_layout()
fig.savefig(os.path.join(OUT, "kucultme.png"), dpi=90)
plt.close(fig)
df_k = pd.DataFrame(rows)
print(df_k.T.to_string())
df_k.to_csv(os.path.join(OUT, "kucultme_sonuclari.csv"), index=False)

# %% Hücre 6 – Çalıştırma bilgisi ve özet tablo
fig, axs = plt.subplots(1, 3, figsize=(12, 6))
for ax, k in zip(axs, ORDER):
    ax.imshow(rgb[k]); ax.set_title(f"{k}  (ort={rgb[k].mean():.0f})"); ax.axis("off")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fotograflar.png"), dpi=80); plt.close(fig)

with open(os.path.join(OUT, "run_info.json"), "w", encoding="utf-8") as f:
    json.dump(dict(versions=versions, files=FILES, rgb_min=RGB_MIN.tolist(), rgb_max=RGB_MAX.tolist(),
                   hsv_min=HSV_MIN.tolist(), hsv_max=HSV_MAX.tolist(), roi=ROI, b_shift=B_SHIFT,
                   gammas=GAMMAS, crops=CROPS, scale=SCALE), f, ensure_ascii=False, indent=2)

# Özet sonuç tablosu (uzun biçim): deney, koşul, ölçüt, değer
uzun = []
for _, r_ in df_yapi.iterrows():
    uzun += [("D1 yapı", r_.foto, "shape", f"({r_.H}, {r_.W}, {r_.C})"), ("D1 yapı", r_.foto, "dtype", r_["dtype"]),
             ("D1 yapı", r_.foto, "ortalama", r_.ortalama)]
for _, r_ in df_piksel.iterrows():
    uzun.append(("D1 piksel", f"{r_.nokta}-{r_.foto}", f"(x={r_.x}, y={r_.y}) R,G,B,H,S,V",
                 f"{r_.R},{r_.G},{r_.B},{r_.H},{r_.S},{r_.V}"))
for _, r_ in df_maske.iterrows():
    uzun += [("D2 maske", f"{r_.foto}-{r_.maske}", "piksel", r_.piksel),
             ("D2 maske", f"{r_.foto}-{r_.maske}", "alan_orani_yuzde", r_.alan_orani_yuzde),
             ("D2 maske", f"{r_.foto}-{r_.maske}", "en_buyuk_disindaki_piksel", r_.en_buyuk_disindaki_piksel)]
for _, r_ in df_pg.iterrows():
    uzun += [("D3 parlaklık/gama", r_.donusum, "ortalama", r_.ortalama),
             ("D3 parlaklık/gama", r_.donusum, "beklenen_naif", r_.beklenen_naif),
             ("D3 parlaklık/gama", r_.donusum, "piksel_255_orani_yuzde", r_.piksel_255_orani_yuzde)]
for _, r_ in df_k.iterrows():
    for c_ in ["std_ozgun", "std_nearest", "std_area", "lapvar_ozgun", "lapvar_nearest", "lapvar_area",
               "MAE_nearest_ozgunle", "MAE_area_ozgunle"]:
        uzun.append(("D4 küçültme", r_.kesit, c_, r_[c_]))
pd.DataFrame(uzun, columns=["deney", "kosul", "olcut", "deger"]).to_csv(
    os.path.join(BASE, "sonuc_tablosu.csv"), index=False, encoding="utf-8")

print("\nTamamlandı. Çıktılar:", sorted(os.listdir(OUT)))

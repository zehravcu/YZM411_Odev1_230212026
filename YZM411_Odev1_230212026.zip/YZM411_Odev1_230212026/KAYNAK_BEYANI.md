# Kaynak ve Yapay Zekâ Beyanı

## Kaynaklar
- Ders notları, Hafta 1–2 (görüntünün sayısal temsili, renk uzayları, örnekleme).
- OpenCV belgeleri: cv2.cvtColor (8 bit HSV: H 0–179, S/V 0–255), cv2.inRange, cv2.resize (INTER_NEAREST, INTER_AREA),
  cv2.connectedComponentsWithStats.
- NumPy belgeleri (dizi erişimi, clip, float işlemleri); SciPy `find_peaks`.
- Veri: tamamı kendi çekimim (telefon kamerası; sarı fosforlu kalem, beyaz kâğıt, çizgili kâğıt, ahşap masa; kişi yok).

## Kendi yaptıklarım
- Deney düzeneğini kurdum, tüm fotoğrafları kendim çektim ve kullanılacak kareleri seçtim.
- Tahminleri (rapor/tahminler.md) kodu çalıştırmadan önce kendim yazdım.
- odev1.py'deki adımların akışını ders notlarına göre kendim belirledim ve kodu yazdım; renk eşikleri, parametreler
  ve yorumlar benim denemelerimle belirlendi.
- Sonuçları yorumladım, tahminlerimle karşılaştırdım ve raporun içeriğini oluşturdum.

## Yapay zekâ beyanı
- **Araç:** Claude Sonnet 5.5 (Anthropic, claude.ai).
- **Kullanım amacı:** yardımcı araç olarak kullandım. Takıldığım yerlerde hata ayıklama ve OpenCV/NumPy fonksiyonlarının
  kullanımıyla ilgili sorular sordum; bazı kod parçaları için öneri aldım ve bunları kendi koduma uyarladım. Ayrıca
  fotoğraf seçimi için parlaklık / kamera kayması ölçümü fikri, rapor PDF'ini oluşturan betiğin (rapor/rapor_olustur.py)
  biçimlendirmesi ve klasör düzeni konusunda destek aldım.
- **Etkilediği dosyalar:** odev1.py (bazı hücrelerde hata düzeltme ve kod önerileri), rapor/rapor_olustur.py
  (biçimlendirme), README.md (düzenleme). Fotoğraflar, tahminler ve sonuç yorumları bana aittir.
- **Nasıl doğrulandı:** önerilen her kodu okuyup anladıktan sonra kullandım; kodu kendim çalıştırdım. Kod içi assert'ler
  ile kontrol ettim (BGR↔RGB eşitliği, ödevdeki 64→128 / 64→16 gama örneği, parlaklık kırpma kaybı eşitliği). Rapordaki
  sayılar results/*.csv dosyalarından aktarıldı; şekilleri gözle kontrol ettim ve çıktıları kendi tahminlerimle karşılaştırdım.
